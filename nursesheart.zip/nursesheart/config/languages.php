<?php

return [
    'en' => 'English',
    'arab' => 'لعربية',
];