<?php 

namespace App\Helpers;

class Helper
{

		  public function testMe() {
			  
			  return "it works";
			  
		  }
	
	
}	


?>